from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')

def wtest(request):
    return render(request,'wtest.html')

def back(request):
    return render(request,'home.html')

def expression(request):
    Wt0= float(request.GET['text8'])
    Vs = float(request.GET['text9'])
    Wi= float(request.GET['text10'])
    Wf = float(request.GET['text11'])
    rhoh = float(request.GET['text12'])
    Vc= float(request.GET['text13'])
    s = float(request.GET['text14'])
    Wavg = ((Wi + Wf) / 2) * 9.81  # average weight of aircraft at cruise
    CLc = (2 * Wavg) / (rhoh * Vc * Vc * s)  # coefficient of Lift at cruise
    CLcw = CLc / 0.95  # coefficient of Lift of wing at cruise
    Clc = CLcw / 0.9  # coefficient of Lift of Aerofoil at cruise
    CLmax = (2 * Wt0) / (rhoh * Vs * Vs * s)  # Maximum coefficient of Lift
    CLmaxw = CLmax / 0.95  # Maximum coefficient of Lift of wing
    Clmaxw = CLmax / 0.9  # Maximum coefficient of Lift of Aerofoil
    return render(request, 'output.html',{'result1':CLc,'result2':CLcw,'result3':Clc,'result4':CLmax,'result5':CLmaxw,'result6':Clmaxw})

def add(request):
    Vt0 = float(request.GET['text1'])
    CLm = float(request.GET['text2'])
    STog = float(request.GET['text3'])
    e = float(request.GET['text4'])
    AR = float(request.GET['text5'])
    CD0 = float(request.GET['text6'])
    L_D = float(request.GET['text7'])
    rho = 1.225  # density in kg/m^3
    A_r = 1  # air ratio
    pi = 3.14159
    Vs = Vt0 / 1.2  # stall velocity in m/s
    W_s = (0.5 * rho * CLm * (Vs ** 2)) / 9.81  # wing loading in kg/sq m
    W_p = ((STog) * (A_r) * (CLm)) / W_s
    P_w = 1 / W_p  # power loading at takeoff in watt/N
    Va = 1.3 * Vs  # aproach velocity in m/s
    Sfl = 0.265 * (Va ** 2)  # landing feild length in m
    k = 1 / (pi * AR * e)
    q = 0.5 * rho * Vt0  # dynamic pressure in N
    T_W = ((CD0 * q) / (W_s)) + (W_s * (k / q))  # thurst loading
    return render(request, 'output2.html',{'result1': W_s ,'result2': T_W })

def sub(request):
    We_Wt0   = float(request.GET['text8'])
    Wpl =      float(request.GET['text9'])
    Wpl_Wt0 =    float(request.GET['text10'])
    Wb_Wt0 = 1 - (Wpl_Wt0) - (We_Wt0)
    Wt0 = Wpl / (1 - ((We_Wt0) + (Wb_Wt0)))  # maximum takeoff weight
    Wb = (Wb_Wt0) * (Wt0)  # weight of fuel in kg
    We = (We_Wt0) * (Wt0)  # Empty weight in kg
    return render(request, 'output3.html',{'result1': Wt0,'result2':Wb,'result3':We})

def emp(request):
    Vv =     float(request.GET['text15'])
    Vh =     float(request.GET['text16'])
    s =      float(request.GET['text17'])
    c =      float(request.GET['text18'])
    Lt =     float(request.GET['text19'])
    ARw=     float(request.GET['text20'])
    CMowf =  float(request.GET['text21'])
    CL =     float(request.GET['text22'])
    h1 =     float(request.GET['text23'])
    h2 =     float(request.GET['text24'])
    n =      float(request.GET['text25'])
    sv = (Vv * c * s) / Lt
    sh = (Vh * c * s) / Lt
    ARht = (2 / 3) * ARw
    CLt = (CMowf * CL * (h1 - h2)) / (n * Vh)
    print(sv, sh, ARht, CLt)
    return render(request, 'output4.html',{'result1': sv,'result2':sh,'result3':ARht,'result4':CLt})



